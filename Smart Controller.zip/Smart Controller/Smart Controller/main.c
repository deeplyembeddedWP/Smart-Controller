#include <atmel_start.h>
#include "driver_examples.h"

#define TASK1_STACK_SIZE				(300 / sizeof(portSTACK_TYPE))
#define TASK1_PRIORITY					(tskIDLE_PRIORITY + 1)

static TaskHandle_t	task1_handler;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	if (xTaskCreate(TARGET_IO_example_task, "Task1", TASK1_STACK_SIZE, NULL, TASK1_PRIORITY, &task1_handler) != pdPASS) {
		while (1);
	}
	vTaskStartScheduler();
	
	return 0;
}
